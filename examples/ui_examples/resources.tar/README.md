# Resources

This folder contains resources required for testing. To use resources, see the ggez-Documentation on how to use a resource folder and pull from there.